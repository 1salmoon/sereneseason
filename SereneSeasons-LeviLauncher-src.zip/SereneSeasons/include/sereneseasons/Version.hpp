#pragma once

#include <cstdint>
#include <string_view>

namespace sereneseasons {

inline constexpr std::string_view Name = "SereneSeasons";
inline constexpr std::string_view Author = "SereneSeasons Bedrock Port";
inline constexpr std::string_view Description = "Client-side seasons for Minecraft Bedrock: seasonal weather, snow, atmosphere tint and a season HUD.";
inline constexpr std::string_view Version = "1.0.0";
inline constexpr std::uint32_t SdkVersion = 1;
inline constexpr std::string_view RuntimeLibrary = "libSereneSeasons.so";

}
