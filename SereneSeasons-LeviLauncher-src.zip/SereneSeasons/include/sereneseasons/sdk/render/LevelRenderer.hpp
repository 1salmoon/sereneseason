#pragma once

#include <sereneseasons/sdk/Memory.hpp>
#include <sereneseasons/sdk/Offsets.hpp>
#include <sereneseasons/sdk/render/LevelRendererPlayer.hpp>

namespace sereneseasons::sdk {

class LevelRenderer {
public:
    void* renderChunkCoordinatorTable() {
        return reinterpret_cast<void*>(reinterpret_cast<std::uintptr_t>(this) + offsets::LevelRenderer::mRenderChunkCoordinators);
    }

    LevelRendererPlayer* playerRenderer() { return field<LevelRendererPlayer*>(this, offsets::LevelRenderer::mLevelRendererPlayer); }
};

}
