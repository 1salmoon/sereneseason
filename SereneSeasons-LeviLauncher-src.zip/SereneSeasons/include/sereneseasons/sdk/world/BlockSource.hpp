#pragma once

#include <sereneseasons/sdk/Memory.hpp>
#include <sereneseasons/sdk/Offsets.hpp>

namespace sereneseasons::sdk {

class BlockSource {
public:
    int dimensionId() {
        return virtualCall<int>(this, offsets::VTable::BlockSource_getDimensionId);
    }
};

}
