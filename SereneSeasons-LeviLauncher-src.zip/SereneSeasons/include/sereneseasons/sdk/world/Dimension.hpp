#pragma once

#include <sereneseasons/sdk/Memory.hpp>
#include <sereneseasons/sdk/Offsets.hpp>
#include <sereneseasons/sdk/world/BlockSource.hpp>
#include <sereneseasons/sdk/world/Weather.hpp>

namespace sereneseasons::sdk {

class Dimension {
public:
    BlockSource* blockSource() { return field<BlockSource*>(this, offsets::Dimension::mBlockSource); }
    Weather* weather() { return field<Weather*>(this, offsets::Dimension::mWeather); }
};

}
