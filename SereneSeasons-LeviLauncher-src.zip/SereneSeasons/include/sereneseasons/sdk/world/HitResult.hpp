#pragma once

#include <sereneseasons/sdk/Memory.hpp>
#include <sereneseasons/sdk/Offsets.hpp>
#include <sereneseasons/sdk/Types.hpp>

namespace sereneseasons::sdk {

class HitResult {
public:
    int type() const { return field<int>(this, offsets::HitResult::mType); }
    const Vec3& startPosition() const { return field<Vec3>(this, offsets::HitResult::mStartPos); }
    const Vec3& position() const { return field<Vec3>(this, offsets::HitResult::mPos); }
};

}
