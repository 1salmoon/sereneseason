#pragma once

#include <sereneseasons/sdk/Memory.hpp>
#include <sereneseasons/sdk/Offsets.hpp>
#include <sereneseasons/sdk/world/HitResult.hpp>

namespace sereneseasons::sdk {

class Level {
public:
    void* actorManager() const { return field<void*>(this, offsets::Level::mActorManager); }

    HitResult* storedHitResult() {
        auto* wrapper = field<void*>(this, offsets::Level::mHitResultWrapper);
        if (!wrapper) return nullptr;
        return reinterpret_cast<HitResult*>(reinterpret_cast<std::uintptr_t>(wrapper) + offsets::HitResultWrapper::mHitResult);
    }

    const HitResult* storedHitResult() const {
        auto* wrapper = field<const void*>(this, offsets::Level::mHitResultWrapper);
        if (!wrapper) return nullptr;
        return reinterpret_cast<const HitResult*>(reinterpret_cast<std::uintptr_t>(wrapper) + offsets::HitResultWrapper::mHitResult);
    }
};

}
