#pragma once

#include <sereneseasons/sdk/offsets/Core.hpp>
#include <sereneseasons/sdk/offsets/World.hpp>
#include <sereneseasons/sdk/offsets/Render.hpp>
#include <sereneseasons/sdk/offsets/Network.hpp>
#include <sereneseasons/sdk/offsets/Skin.hpp>
#include <sereneseasons/sdk/offsets/UI.hpp>

#include <sereneseasons/sdk/offsets/Inventory.hpp>
