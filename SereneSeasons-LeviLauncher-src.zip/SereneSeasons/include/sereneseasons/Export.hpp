#pragma once

#if defined(__GNUC__) || defined(__clang__)
#define SERENESEASONS_API __attribute__((visibility("default")))
#else
#define SERENESEASONS_API
#endif
