#pragma once

#include <sereneseasons/events/Event.hpp>

namespace sereneseasons::events {

struct FrameEvent {
    static constexpr EventType type = EventType::Frame;
};

}
