#pragma once

#include <sereneseasons/events/Event.hpp>

namespace sereneseasons::events {

struct MouseInputEvent : Cancellable {
    static constexpr EventType type = EventType::MouseInput;

    MouseInputEvent(int mouseButton, bool isDown) : button(mouseButton), down(isDown) {}

    int button;
    bool down;
};

}
