#pragma once

#include <sereneseasons/events/Event.hpp>

namespace sereneseasons::sdk { class Player; }

namespace sereneseasons::events {

struct LocalPlayerPreTickEvent {
    static constexpr EventType type = EventType::LocalPlayerPreTick;
    sdk::Player* player;
};

}
