#pragma once

#include <sereneseasons/events/Event.hpp>

namespace sereneseasons::sdk { class ClientInstance; }

namespace sereneseasons::events {

struct ClientInstanceUpdateEvent {
    static constexpr EventType type = EventType::ClientInstanceUpdate;
    sdk::ClientInstance* clientInstance;
};

}
