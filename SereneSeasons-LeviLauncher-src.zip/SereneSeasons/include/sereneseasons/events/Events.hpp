#pragma once

#include <sereneseasons/events/Event.hpp>
#include <sereneseasons/events/FrameEvent.hpp>
#include <sereneseasons/events/LocalPlayerTickEvent.hpp>
#include <sereneseasons/events/LocalPlayerPreTickEvent.hpp>
#include <sereneseasons/events/ClientInstanceUpdateEvent.hpp>
#include <sereneseasons/events/AttackEvent.hpp>
#include <sereneseasons/events/GameModeActionEvent.hpp>
#include <sereneseasons/events/MouseInputEvent.hpp>
#include <sereneseasons/events/ScreenStateEvent.hpp>

#include <sereneseasons/events/ContainerSlotSelectedEvent.hpp>
