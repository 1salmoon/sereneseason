#pragma once

#include <sereneseasons/events/Event.hpp>

namespace sereneseasons::sdk { class Player; }

namespace sereneseasons::events {

struct LocalPlayerTickEvent {
    static constexpr EventType type = EventType::LocalPlayerTick;
    sdk::Player* player;
};

}
