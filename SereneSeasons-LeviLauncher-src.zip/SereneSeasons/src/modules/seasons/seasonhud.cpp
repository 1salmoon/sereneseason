#include "seasonhud.hpp"
#include "seasons.hpp"
#include "modules/ModuleRegistry.hpp"
#include <pl/ModMenu.hpp>
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <string>
#include <vector>

namespace {

namespace ss = sereneseasons::seasons;

std::uint32_t seasonColor(ss::Season season) {
    switch (season) {
        case ss::Season::Spring: return 0xFF7BD66B;
        case ss::Season::Summer: return 0xFFFFD84A;
        case ss::Season::Autumn: return 0xFFE8872B;
        case ss::Season::Winter: return 0xFF9ED8FF;
    }
    return 0xFFFFFFFF;
}

float textWidth(const std::string& text, float size) {
    float width = 0.0f;
    for (char c : text) {
        if (c == 'i' || c == 'l' || c == '1' || c == ':' || c == '.' || c == ' ' || c == '/') width += size * 0.3f;
        else if (c == 'm' || c == 'w' || c == 'M' || c == 'W') width += size * 0.8f;
        else width += size * 0.58f;
    }
    return width;
}

}

SeasonHudModule::SeasonHudModule()
    : Module("Season HUD", "Shows the current season and day on screen.") {
    masterEnabled = true;
    enabled = true;
}

void SeasonHudModule::onFrame() {
    if (!enabled) return;
    ss::State state;
    if (!SeasonsModule::snapshot(state)) {
        pl::modmenu::submitDrawCommands(moduleId, {});
        return;
    }

    float x, y, size, opacity;
    bool showDay, showYear, background;
    {
        std::lock_guard lock(m_configMutex);
        x = hudPosX; y = hudPosY; size = m_size; opacity = m_backgroundOpacity;
        showDay = m_showDay; showYear = m_showYear; background = m_background;
    }

    std::string title = ss::subSeasonName(state.subSeason);
    if (showYear) title += "  (Year " + std::to_string(state.year) + ")";
    std::string detail;
    if (showDay) {
        char buffer[48];
        std::snprintf(buffer, sizeof(buffer), "Day %d/%d", state.dayInSubSeason + 1, state.subSeasonDays);
        detail = buffer;
    }

    const float lineHeight = size + 2.0f;
    const float width = std::max(textWidth(title, size), textWidth(detail, size * 0.8f)) + 12.0f;
    const float height = lineHeight * (detail.empty() ? 1.0f : 1.8f) + 6.0f;

    std::vector<pl::modmenu::DrawCommand> commands;
    if (background) {
        pl::modmenu::DrawCommand box;
        box.type = pl::modmenu::DrawCommandType::RectFilled;
        box.x = x; box.y = y; box.w = width; box.h = height;
        box.color = static_cast<std::uint32_t>(opacity * 255.0f) << 24;
        commands.push_back(std::move(box));
    }

    pl::modmenu::DrawCommand label;
    label.type = pl::modmenu::DrawCommandType::Text;
    label.x = x + 4.0f; label.y = y + 3.0f; label.w = width; label.h = lineHeight;
    label.size = size;
    label.color = seasonColor(state.season);
    label.text = title;
    commands.push_back(std::move(label));

    if (!detail.empty()) {
        pl::modmenu::DrawCommand sub;
        sub.type = pl::modmenu::DrawCommandType::Text;
        sub.x = x + 4.0f; sub.y = y + 3.0f + lineHeight; sub.w = width; sub.h = lineHeight;
        sub.size = size * 0.8f;
        sub.color = 0xFFFFFFFF;
        sub.text = detail;
        commands.push_back(std::move(sub));
    }
    pl::modmenu::submitDrawCommands(moduleId, commands);
}

void SeasonHudModule::onMenuRegistered() {
    using namespace pl::modmenu;
    ConfigSchemaBuilder schema;
    schema.defaultCategory("display")
        .category("display", "Display", "What the HUD shows")
        .category("appearance", "Appearance", "Text and background");
    auto node = [](const char* key, const char* title, const char* category, ConfigControlTypeV2 type) {
        ConfigNodeV2 value;
        value.id = key;
        value.key = key;
        value.title = title;
        value.category = category;
        value.type = type;
        return value;
    };
    schema.node(node("m_showDay", "Show Day Counter", "display", ConfigControlTypeV2::Toggle));
    schema.node(node("m_showYear", "Show Year", "display", ConfigControlTypeV2::Toggle));
    schema.node(node("keybind", "Keybind", "display", ConfigControlTypeV2::Keybind));
    auto size = node("m_size", "Text Size", "appearance", ConfigControlTypeV2::SliderFloat);
    size.minValue = "6";
    size.maxValue = "100";
    size.step = "1";
    size.unit = " px";
    schema.node(std::move(size));
    schema.node(node("m_background", "Background", "appearance", ConfigControlTypeV2::Toggle));
    auto opacity = node("m_backgroundOpacity", "Background Opacity", "appearance", ConfigControlTypeV2::SliderFloat);
    opacity.minValue = "0";
    opacity.maxValue = "1";
    opacity.step = "0.01";
    opacity.visibleWhen = {{"m_background", ConfigConditionOpV2::Truthy, {}}};
    schema.node(std::move(opacity));
    setConfigSchemaJson(moduleId, schema.toJson());
}

void SeasonHudModule::loadConfig(const nlohmann::json& j) {
    Module::loadConfig(j);
    std::lock_guard lock(m_configMutex);
    if (j.contains("hudPosX")) hudPosX = std::clamp(j["hudPosX"].get<float>(), 0.0f, 4000.0f);
    if (j.contains("hudPosY")) hudPosY = std::clamp(j["hudPosY"].get<float>(), 0.0f, 4000.0f);
    if (j.contains("m_size")) m_size = std::clamp(j["m_size"].get<float>(), 6.0f, 100.0f);
    if (j.contains("m_showDay")) m_showDay = j["m_showDay"].get<bool>();
    if (j.contains("m_showYear")) m_showYear = j["m_showYear"].get<bool>();
    if (j.contains("m_background")) m_background = j["m_background"].get<bool>();
    if (j.contains("m_backgroundOpacity")) m_backgroundOpacity = std::clamp(j["m_backgroundOpacity"].get<float>(), 0.0f, 1.0f);
}

void SeasonHudModule::saveConfig(nlohmann::json& j) {
    Module::saveConfig(j);
    std::lock_guard lock(m_configMutex);
    j["hudPosX"] = hudPosX;
    j["hudPosY"] = hudPosY;
    j["isHudModule"] = true;
    j["m_size"] = m_size;
    j["m_showDay"] = m_showDay;
    j["m_showYear"] = m_showYear;
    j["m_background"] = m_background;
    j["m_backgroundOpacity"] = m_backgroundOpacity;
}
