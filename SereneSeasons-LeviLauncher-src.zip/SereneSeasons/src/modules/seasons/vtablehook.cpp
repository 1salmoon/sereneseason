#include "vtablehook.hpp"

#include <sys/mman.h>
#include <unistd.h>

#include <cstdio>
#include <cstring>
#include <fstream>
#include <string>
#include <string_view>
#include <vector>

namespace sereneseasons::vthook {
namespace {

struct Map {
    std::uintptr_t start, end;
    bool exec;
    unsigned long long offset;
};

std::vector<Map> readMaps() {
    std::vector<Map> out;
    std::ifstream maps("/proc/self/maps");
    std::string line;
    while (std::getline(maps, line)) {
        if (line.find("libminecraftpe.so") == std::string::npos) continue;
        unsigned long long s = 0, e = 0, off = 0;
        char perms[8] = {};
        if (std::sscanf(line.c_str(), "%llx-%llx %7s %llx", &s, &e, perms, &off) != 4) continue;
        if (perms[0] != 'r') continue;
        const bool exec = perms[2] == 'x';
        // Raw read-only mirror of the whole file, not the loaded image.
        if (!exec && off == 0 && e - s > 0x10000000ull) continue;
        out.push_back({static_cast<std::uintptr_t>(s), static_cast<std::uintptr_t>(e), exec, off});
    }
    return out;
}

std::uintptr_t findName(const std::vector<Map>& maps, const std::string& name) {
    const std::string needle = std::string(1, '\0') + name + std::string(1, '\0');
    for (const auto& m : maps) {
        std::string_view hay(reinterpret_cast<const char*>(m.start), m.end - m.start);
        const auto pos = hay.find(needle);
        if (pos != std::string_view::npos) return m.start + pos + 1;
    }
    return 0;
}

std::uintptr_t findSlot(const std::vector<Map>& maps, std::uintptr_t value) {
    for (const auto& m : maps) {
        if (m.exec) continue;
        for (std::uintptr_t p = m.start; p + 8 <= m.end; p += 8)
            if (*reinterpret_cast<const std::uintptr_t*>(p) == value) return p;
    }
    return 0;
}

}  // namespace

std::uintptr_t* findVtable(const char* mangledTypeName) {
    const auto maps = readMaps();
    if (maps.empty()) return nullptr;
    const auto name = findName(maps, mangledTypeName);
    if (!name) return nullptr;
    const auto nameSlot = findSlot(maps, name);          // typeinfo = [vptr, name]
    if (!nameSlot) return nullptr;
    const auto typeinfo = nameSlot - 8;
    const auto vtableSlot = findSlot(maps, typeinfo);    // vtable[-1] = typeinfo
    if (!vtableSlot) return nullptr;
    return reinterpret_cast<std::uintptr_t*>(vtableSlot + 8);
}

bool patchSlot(std::uintptr_t* vtable, int slot, void* detour, void** original) {
    if (!vtable || slot < 0 || !detour) return false;
    auto* target = vtable + slot;
    const auto page = static_cast<std::uintptr_t>(sysconf(_SC_PAGESIZE));
    const auto begin = reinterpret_cast<std::uintptr_t>(target) & ~(page - 1);
    if (mprotect(reinterpret_cast<void*>(begin), page * 2, PROT_READ | PROT_WRITE) != 0) return false;
    if (original && !*original) *original = reinterpret_cast<void*>(*target);
    __atomic_store_n(target, reinterpret_cast<std::uintptr_t>(detour), __ATOMIC_RELEASE);
    mprotect(reinterpret_cast<void*>(begin), page * 2, PROT_READ);
    return true;
}

}  // namespace sereneseasons::vthook
