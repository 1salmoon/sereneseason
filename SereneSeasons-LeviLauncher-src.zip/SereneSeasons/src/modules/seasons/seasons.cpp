#include "seasons.hpp"
#include "vtablehook.hpp"
#include <thread>
#include "modules/ModuleRegistry.hpp"
#include "core/memory/Hooks.hpp"
#include <sereneseasons/events/EventBus.hpp>
#include <sereneseasons/memory/Signatures.hpp>
#include <sereneseasons/sdk/world/Actor.hpp>
#include <sereneseasons/sdk/world/Dimension.hpp>
#include <sereneseasons/sdk/world/Level.hpp>
#include <sereneseasons/sdk/world/Weather.hpp>
#include <sereneseasons/sdk/Offsets.hpp>
#include <pl/ModMenu.hpp>
#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstdlib>

namespace sm = sereneseasons::memory;
namespace ss = sereneseasons::seasons;
using sereneseasons::hooks::Handle;

namespace {

SeasonsModule* g_mod = nullptr;

// ---- shared clock state ---------------------------------------------------
std::mutex g_stateMutex;
ss::State g_state;
std::atomic_bool g_stateValid{false};
std::atomic<int> g_lastSetTime{-1};

// ---- effect state read by hooks (written from the tick thread) ------------
std::atomic<float> g_rain{0.0f};
std::atomic<float> g_lightning{0.0f};
std::atomic_bool g_weatherOn{false};
std::atomic_bool g_snowOn{false};
std::atomic_bool g_tintOn{false};
std::atomic<float> g_tintR{1.0f}, g_tintG{1.0f}, g_tintB{1.0f};
std::atomic<sereneseasons::sdk::Weather*> g_lastWeather{nullptr};

// ---- grass / foliage colour (vtable patch) ------------------------------------
struct Color4 { float r, g, b, a; };
using ColorFn = Color4 (*)(std::uintptr_t, std::uintptr_t, std::uintptr_t, std::uintptr_t, std::uintptr_t,
                           std::uintptr_t, std::uintptr_t, std::uintptr_t, float, float, float, float, float,
                           float, float, float);
std::atomic_bool g_colorOn{false};
std::atomic<float> g_grassTint[3] = {1.0f, 1.0f, 1.0f};
std::atomic<float> g_foliageTint[3] = {1.0f, 1.0f, 1.0f};
void* g_colorOrig[2][4] = {};  // [0]=grass [1]=foliage, per vtable slot
std::atomic_bool g_colorBusy{false};
int g_patchedSlot = -1;
std::uintptr_t* g_vtables[2] = {nullptr, nullptr};

constexpr int kWeatherWindowTicks = 6000;  // weather re-rolled 4x per day
constexpr float kFadePerTick = 0.01f;      // ~5 s to fade rain in/out

bool effectsOn() { return g_mod && g_mod->enabled; }

// ---- original function pointers ------------------------------------------
using GetTimeFn = int (*)(void*);
using SetTimeFn = void (*)(void*, int);
using FogFn = void (*)(void*, void*);
using TickFn = void (*)(void*);
using LevelFn = float (*)(void*, float);
using StateFn = bool (*)(void*);
using TempFn = float (*)(void*, void*, void*);

GetTimeFn s_getTime = nullptr;
SetTimeFn s_setTime = nullptr;
FogFn s_fog = nullptr;
TickFn s_dimTick = nullptr;
TickFn s_weatherTick = nullptr;
LevelFn s_rainLevel = nullptr;
LevelFn s_lightningLevel = nullptr;
StateFn s_isRaining = nullptr;
StateFn s_isLightning = nullptr;
TempFn s_temperature = nullptr;

Handle h_getTime, h_setTime, h_fog, h_dimTick, h_weatherTick, h_rain, h_lightning, h_isRaining, h_isLightning, h_temp;

void forceWeather(sereneseasons::sdk::Weather* weather) {
    if (!weather) return;
    g_lastWeather.store(weather, std::memory_order_release);
    if (!g_weatherOn.load(std::memory_order_relaxed) || !effectsOn()) return;
    weather->setRainLevel(g_rain.load(std::memory_order_relaxed));
    weather->setLightningLevel(g_lightning.load(std::memory_order_relaxed));
}

// ---- hooks ------------------------------------------------------------------
int getTimeHook(void* level) { return s_getTime ? s_getTime(level) : 0; }

void setTimeHook(void* level, int time) {
    g_lastSetTime.store(time, std::memory_order_relaxed);
    if (s_setTime) s_setTime(level, time);
}

void fogHook(void* self, void* arg) {
    if (s_fog) s_fog(self, arg);
    if (!self || !g_tintOn.load(std::memory_order_relaxed) || !effectsOn()) return;
    using namespace sereneseasons::sdk::offsets;
    auto* r = reinterpret_cast<float*>(reinterpret_cast<std::uintptr_t>(self) + LevelRendererPlayer::mFogColorRed);
    auto* g = reinterpret_cast<float*>(reinterpret_cast<std::uintptr_t>(self) + LevelRendererPlayer::mFogColorGreen);
    auto* b = reinterpret_cast<float*>(reinterpret_cast<std::uintptr_t>(self) + LevelRendererPlayer::mFogColorBlue);
    *r = std::clamp(*r * g_tintR.load(std::memory_order_relaxed), 0.0f, 1.0f);
    *g = std::clamp(*g * g_tintG.load(std::memory_order_relaxed), 0.0f, 1.0f);
    *b = std::clamp(*b * g_tintB.load(std::memory_order_relaxed), 0.0f, 1.0f);
}

void dimTickHook(void* dimension) {
    auto* typed = static_cast<sereneseasons::sdk::Dimension*>(dimension);
    auto* weather = typed ? typed->weather() : nullptr;
    forceWeather(weather);
    if (s_dimTick) s_dimTick(dimension);
    forceWeather(weather);
}

void weatherTickHook(void* weather) {
    forceWeather(static_cast<sereneseasons::sdk::Weather*>(weather));
    if (s_weatherTick) s_weatherTick(weather);
    forceWeather(static_cast<sereneseasons::sdk::Weather*>(weather));
}

float rainLevelHook(void* weather, float delta) {
    if (g_weatherOn.load(std::memory_order_relaxed) && effectsOn()) return g_rain.load(std::memory_order_relaxed);
    return s_rainLevel ? s_rainLevel(weather, delta) : 0.0f;
}

float lightningLevelHook(void* weather, float delta) {
    if (g_weatherOn.load(std::memory_order_relaxed) && effectsOn()) return g_lightning.load(std::memory_order_relaxed);
    return s_lightningLevel ? s_lightningLevel(weather, delta) : 0.0f;
}

bool isRainingHook(void* weather) {
    if (g_weatherOn.load(std::memory_order_relaxed) && effectsOn()) return g_rain.load(std::memory_order_relaxed) > 0.2f;
    return s_isRaining ? s_isRaining(weather) : false;
}

bool isLightningHook(void* weather) {
    if (g_weatherOn.load(std::memory_order_relaxed) && effectsOn()) return g_lightning.load(std::memory_order_relaxed) > 0.2f;
    return s_isLightning ? s_isLightning(weather) : false;
}

// In winter, precipitation falls as snow in every non-hot biome.
float temperatureHook(void* biome, void* blockSource, void* pos) {
    const float original = s_temperature ? s_temperature(biome, blockSource, pos) : 0.5f;
    if (g_snowOn.load(std::memory_order_relaxed) && effectsOn() && original < 0.9f) return std::min(original, 0.0f);
    return original;
}

bool plausible(const Color4& c) {
    return std::isfinite(c.r) && std::isfinite(c.g) && std::isfinite(c.b) && c.r >= 0.0f && c.g >= 0.0f &&
           c.b >= 0.0f && c.r <= 2.0f && c.g <= 2.0f && c.b <= 2.0f;
}

// Every register argument is forwarded untouched so the call is transparent whatever the real signature is.
template <int Policy, int Slot>
Color4 colorDetour(std::uintptr_t a0, std::uintptr_t a1, std::uintptr_t a2, std::uintptr_t a3, std::uintptr_t a4,
                   std::uintptr_t a5, std::uintptr_t a6, std::uintptr_t a7, float f0, float f1, float f2, float f3,
                   float f4, float f5, float f6, float f7) {
    auto original = reinterpret_cast<ColorFn>(g_colorOrig[Policy][Slot]);
    Color4 c = original ? original(a0, a1, a2, a3, a4, a5, a6, a7, f0, f1, f2, f3, f4, f5, f6, f7) : Color4{1, 1, 1, 1};
    if (g_colorOn.load(std::memory_order_relaxed) && effectsOn() && plausible(c)) {
        const auto& t = Policy == 0 ? g_grassTint : g_foliageTint;
        c.r = std::clamp(c.r * t[0].load(std::memory_order_relaxed), 0.0f, 1.0f);
        c.g = std::clamp(c.g * t[1].load(std::memory_order_relaxed), 0.0f, 1.0f);
        c.b = std::clamp(c.b * t[2].load(std::memory_order_relaxed), 0.0f, 1.0f);
    }
    return c;
}

void* const kDetours[2][4] = {
    {nullptr, reinterpret_cast<void*>(colorDetour<0, 1>), reinterpret_cast<void*>(colorDetour<0, 2>), reinterpret_cast<void*>(colorDetour<0, 3>)},
    {nullptr, reinterpret_cast<void*>(colorDetour<1, 1>), reinterpret_cast<void*>(colorDetour<1, 2>), reinterpret_cast<void*>(colorDetour<1, 3>)}};

// Patch (or move) the colour hook to `slot` (1..3). Runs once on a worker thread; the scan takes a moment.
void applyColorHook(int slot) {
    if (g_colorBusy.exchange(true)) return;
    std::thread([slot] {
        static const char* names[2] = {"N18BiomeColorSampling23GrassTessellationPolicyE",
                                       "N18BiomeColorSampling25FoliageTessellationPolicyE"};
        for (int p = 0; p < 2; ++p) {
            if (!g_vtables[p]) g_vtables[p] = sereneseasons::vthook::findVtable(names[p]);
            if (!g_vtables[p]) continue;
            if (g_patchedSlot >= 1 && g_patchedSlot != slot && g_colorOrig[p][g_patchedSlot])
                sereneseasons::vthook::patchSlot(g_vtables[p], g_patchedSlot, g_colorOrig[p][g_patchedSlot], nullptr);
            sereneseasons::vthook::patchSlot(g_vtables[p], slot, kDetours[p][slot], &g_colorOrig[p][slot]);
        }
        g_patchedSlot = slot;
        g_colorBusy.store(false);
    }).detach();
}

Handle install(sm::SignatureId id, void* detour, void** original) {
    const auto address = sm::resolve(id);
    if (!address) return nullptr;
    return sereneseasons::hooks::install(reinterpret_cast<void*>(address), detour, original);
}

float approach(float current, float target) {
    if (current < target) return std::min(current + kFadePerTick, target);
    return std::max(current - kFadePerTick, target);
}

void onPlayerTick(sereneseasons::sdk::Player* player) {
    if (!player || !g_mod) return;
    auto* level = player->level();
    if (!level) {
        g_stateValid.store(false, std::memory_order_release);
        return;
    }
    int rawTime = s_getTime ? s_getTime(level) : g_lastSetTime.load(std::memory_order_relaxed);
    if (rawTime < 0) {
        g_stateValid.store(false, std::memory_order_release);
        return;
    }

    const auto settings = g_mod->settings();
    const auto state = ss::compute(rawTime, settings);
    {
        std::lock_guard lock(g_stateMutex);
        g_state = state;
    }
    g_stateValid.store(true, std::memory_order_release);

    // Atmosphere tint.
    const bool tint = g_mod->m_tintAtmosphere;
    g_tintOn.store(tint, std::memory_order_relaxed);
    if (tint) {
        const auto t = ss::atmosphereTint(state.yearFraction);
        const float k = std::clamp(g_mod->m_tintStrength, 0.0f, 1.0f);
        g_tintR.store(1.0f + (t.r - 1.0f) * k, std::memory_order_relaxed);
        g_tintG.store(1.0f + (t.g - 1.0f) * k, std::memory_order_relaxed);
        g_tintB.store(1.0f + (t.b - 1.0f) * k, std::memory_order_relaxed);
    }

    // Grass / leaf colour.
    if (g_mod->m_seasonalFoliage) {
        const float k = std::clamp(g_mod->m_foliageStrength, 0.0f, 1.0f);
        const auto g = ss::grassTint(state.yearFraction);
        const auto l = ss::foliageTint(state.yearFraction);
        g_grassTint[0].store(1.0f + (g.r - 1.0f) * k, std::memory_order_relaxed);
        g_grassTint[1].store(1.0f + (g.g - 1.0f) * k, std::memory_order_relaxed);
        g_grassTint[2].store(1.0f + (g.b - 1.0f) * k, std::memory_order_relaxed);
        g_foliageTint[0].store(1.0f + (l.r - 1.0f) * k, std::memory_order_relaxed);
        g_foliageTint[1].store(1.0f + (l.g - 1.0f) * k, std::memory_order_relaxed);
        g_foliageTint[2].store(1.0f + (l.b - 1.0f) * k, std::memory_order_relaxed);
        const int slot = std::clamp(g_mod->m_foliageSlot, 1, 3);
        if (!g_colorBusy.load() && g_patchedSlot != slot) applyColorHook(slot);
    }
    g_colorOn.store(g_mod->m_seasonalFoliage, std::memory_order_relaxed);

    // Snow in winter.
    g_snowOn.store(g_mod->m_winterSnow && state.season == ss::Season::Winter, std::memory_order_relaxed);

    // Seasonal weather.
    const bool weather = g_mod->m_seasonalWeather;
    g_weatherOn.store(weather, std::memory_order_relaxed);
    if (weather) {
        const auto target = ss::weatherForWindow(rawTime / kWeatherWindowTicks, state.season);
        const float rain = approach(g_rain.load(std::memory_order_relaxed), target.rain);
        const float bolt = approach(g_lightning.load(std::memory_order_relaxed), std::min(target.lightning, rain));
        g_rain.store(rain, std::memory_order_relaxed);
        g_lightning.store(bolt, std::memory_order_relaxed);
        if (g_mod->enabled) {
            if (auto* dimension = player->dimension()) forceWeather(dimension->weather());
        }
    }
}

}  // namespace

SeasonsModule::SeasonsModule()
    : Module("Seasons", "Client-side seasons: seasonal weather, winter snow and atmosphere tint.") {
    masterEnabled = true;
    enabled = true;
    g_mod = this;
}

SeasonsModule::~SeasonsModule() {
    sereneseasons::events::bus().unsubscribe(m_subscription);
    if (g_mod == this) g_mod = nullptr;
}

bool SeasonsModule::snapshot(ss::State& out) {
    if (!g_stateValid.load(std::memory_order_acquire)) return false;
    std::lock_guard lock(g_stateMutex);
    out = g_state;
    return true;
}

ss::Settings SeasonsModule::settings() const {
    std::lock_guard lock(m_mutex);
    auto s = m_settings;
    s.seasonOverride = m_override - 1;
    return s;
}

void SeasonsModule::installHooks() {
    using Id = sm::SignatureId;
    if (!h_getTime) h_getTime = install(Id::Time, reinterpret_cast<void*>(getTimeHook), reinterpret_cast<void**>(&s_getTime));
    if (!h_setTime) h_setTime = install(Id::SetTime, reinterpret_cast<void*>(setTimeHook), reinterpret_cast<void**>(&s_setTime));
    if (!h_fog) h_fog = install(Id::SetupFogPlayer, reinterpret_cast<void*>(fogHook), reinterpret_cast<void**>(&s_fog));
    if (!h_dimTick) h_dimTick = install(Id::DimensionTick, reinterpret_cast<void*>(dimTickHook), reinterpret_cast<void**>(&s_dimTick));
    if (!h_weatherTick) h_weatherTick = install(Id::WeatherTick, reinterpret_cast<void*>(weatherTickHook), reinterpret_cast<void**>(&s_weatherTick));
    if (!h_rain) h_rain = install(Id::WeatherGetRainLevel, reinterpret_cast<void*>(rainLevelHook), reinterpret_cast<void**>(&s_rainLevel));
    if (!h_lightning) h_lightning = install(Id::WeatherGetLightningLevel, reinterpret_cast<void*>(lightningLevelHook), reinterpret_cast<void**>(&s_lightningLevel));
    if (!h_isRaining) h_isRaining = install(Id::WeatherIsRaining, reinterpret_cast<void*>(isRainingHook), reinterpret_cast<void**>(&s_isRaining));
    if (!h_isLightning) h_isLightning = install(Id::WeatherIsLightning, reinterpret_cast<void*>(isLightningHook), reinterpret_cast<void**>(&s_isLightning));
    if (!h_temp) h_temp = install(Id::BiomeGetTemperature, reinterpret_cast<void*>(temperatureHook), reinterpret_cast<void**>(&s_temperature));
    m_hooked = h_getTime || h_setTime;
}

void SeasonsModule::onInit() {
    installHooks();
    m_subscription = sereneseasons::events::bus().subscribe<sereneseasons::events::LocalPlayerTickEvent>(
        [](auto& event) { onPlayerTick(event.player); });
}

void SeasonsModule::onEnable() {
    if (!m_hooked) installHooks();
}

void SeasonsModule::onDisable() {
    g_rain.store(0.0f, std::memory_order_relaxed);
    g_lightning.store(0.0f, std::memory_order_relaxed);
}

void SeasonsModule::onMenuRegistered() {
    using namespace pl::modmenu;
    ConfigSchemaBuilder schema;
    schema.defaultCategory("calendar")
        .category("calendar", "Calendar", "Season length and starting point")
        .category("effects", "Effects", "Weather and atmosphere");
    auto node = [](const char* key, const char* title, const char* category, ConfigControlTypeV2 type) {
        ConfigNodeV2 value;
        value.id = key;
        value.key = key;
        value.title = title;
        value.category = category;
        value.type = type;
        return value;
    };

    auto mode = node("m_override", "Season", "calendar", ConfigControlTypeV2::Choice);
    mode.choiceStyle = ConfigChoiceStyleV2::Dropdown;
    mode.options = {{"0", "Automatic (world time)"}, {"1", "Always Spring"}, {"2", "Always Summer"},
                    {"3", "Always Autumn"}, {"4", "Always Winter"}};
    schema.node(std::move(mode));

    auto start = node("m_startSubSeason", "Starting Sub-Season", "calendar", ConfigControlTypeV2::Choice);
    start.choiceStyle = ConfigChoiceStyleV2::Dropdown;
    start.options = {{"0", "Early Spring"}, {"1", "Mid Spring"}, {"2", "Late Spring"},
                     {"3", "Early Summer"}, {"4", "Mid Summer"}, {"5", "Late Summer"},
                     {"6", "Early Autumn"}, {"7", "Mid Autumn"}, {"8", "Late Autumn"},
                     {"9", "Early Winter"}, {"10", "Mid Winter"}, {"11", "Late Winter"}};
    schema.node(std::move(start));

    auto length = node("m_subSeasonDays", "Sub-Season Length", "calendar", ConfigControlTypeV2::SliderInt);
    length.minValue = "1";
    length.maxValue = "60";
    length.step = "1";
    length.unit = " days";
    schema.node(std::move(length));

    schema.node(node("m_seasonalFoliage", "Seasonal Grass/Leaf Color (experimental)", "effects", ConfigControlTypeV2::Toggle));
    auto foliageStrength = node("m_foliageStrength", "Grass/Leaf Strength", "effects", ConfigControlTypeV2::SliderFloat);
    foliageStrength.minValue = "0";
    foliageStrength.maxValue = "1";
    foliageStrength.step = "0.05";
    foliageStrength.visibleWhen = {{"m_seasonalFoliage", ConfigConditionOpV2::Truthy, {}}};
    schema.node(std::move(foliageStrength));
    auto foliageSlot = node("m_foliageSlot", "Colour Hook Slot (try 2, then 1)", "effects", ConfigControlTypeV2::Choice);
    foliageSlot.choiceStyle = ConfigChoiceStyleV2::Dropdown;
    foliageSlot.options = {{"1", "Slot 1"}, {"2", "Slot 2"}, {"3", "Slot 3"}};
    foliageSlot.visibleWhen = {{"m_seasonalFoliage", ConfigConditionOpV2::Truthy, {}}};
    schema.node(std::move(foliageSlot));
    schema.node(node("m_seasonalWeather", "Seasonal Weather", "effects", ConfigControlTypeV2::Toggle));
    schema.node(node("m_winterSnow", "Snow In Winter", "effects", ConfigControlTypeV2::Toggle));
    schema.node(node("m_tintAtmosphere", "Atmosphere Tint", "effects", ConfigControlTypeV2::Toggle));
    auto strength = node("m_tintStrength", "Tint Strength", "effects", ConfigControlTypeV2::SliderFloat);
    strength.minValue = "0";
    strength.maxValue = "1";
    strength.step = "0.05";
    strength.visibleWhen = {{"m_tintAtmosphere", ConfigConditionOpV2::Truthy, {}}};
    schema.node(std::move(strength));
    setConfigSchemaJson(moduleId, schema.toJson());
}

void SeasonsModule::loadConfig(const nlohmann::json& j) {
    Module::loadConfig(j);
    std::lock_guard lock(m_mutex);
    if (j.contains("m_override")) m_override = std::clamp(j["m_override"].get<int>(), 0, 4);
    if (j.contains("m_startSubSeason")) m_settings.startSubSeason = std::clamp(j["m_startSubSeason"].get<int>(), 0, 11);
    if (j.contains("m_subSeasonDays")) m_settings.subSeasonDays = std::clamp(j["m_subSeasonDays"].get<int>(), 1, 60);
    if (j.contains("m_seasonalWeather")) m_seasonalWeather = j["m_seasonalWeather"].get<bool>();
    if (j.contains("m_winterSnow")) m_winterSnow = j["m_winterSnow"].get<bool>();
    if (j.contains("m_tintAtmosphere")) m_tintAtmosphere = j["m_tintAtmosphere"].get<bool>();
    if (j.contains("m_seasonalFoliage")) m_seasonalFoliage = j["m_seasonalFoliage"].get<bool>();
    if (j.contains("m_foliageStrength")) m_foliageStrength = std::clamp(j["m_foliageStrength"].get<float>(), 0.0f, 1.0f);
    if (j.contains("m_foliageSlot")) m_foliageSlot = std::clamp(j["m_foliageSlot"].get<int>(), 1, 3);
    if (j.contains("m_tintStrength")) m_tintStrength = std::clamp(j["m_tintStrength"].get<float>(), 0.0f, 1.0f);
}

void SeasonsModule::saveConfig(nlohmann::json& j) {
    Module::saveConfig(j);
    std::lock_guard lock(m_mutex);
    j["m_override"] = m_override;
    j["m_startSubSeason"] = m_settings.startSubSeason;
    j["m_subSeasonDays"] = m_settings.subSeasonDays;
    j["m_seasonalWeather"] = m_seasonalWeather;
    j["m_winterSnow"] = m_winterSnow;
    j["m_tintAtmosphere"] = m_tintAtmosphere;
    j["m_tintStrength"] = m_tintStrength;
    j["m_seasonalFoliage"] = m_seasonalFoliage;
    j["m_foliageStrength"] = m_foliageStrength;
    j["m_foliageSlot"] = m_foliageSlot;
}
