#pragma once

#include "../Module.hpp"
#include "clock.hpp"
#include <mutex>

class SeasonsModule : public Module {
public:
    SeasonsModule();
    ~SeasonsModule() override;

    void onInit() override;
    void onEnable() override;
    void onDisable() override;
    void onMenuRegistered() override;
    void loadConfig(const nlohmann::json& j) override;
    void saveConfig(nlohmann::json& j) override;

    // Thread-safe snapshot of the current season. False until a world is loaded.
    static bool snapshot(sereneseasons::seasons::State& out);

    sereneseasons::seasons::Settings settings() const;

    bool m_seasonalWeather = true;
    bool m_winterSnow = true;
    bool m_tintAtmosphere = true;
    float m_tintStrength = 0.6f;
    bool m_seasonalFoliage = false;  // experimental: patches the grass/foliage tessellation policies
    float m_foliageStrength = 0.8f;
    int m_foliageSlot = 2;

private:
    void installHooks();

    mutable std::mutex m_mutex;
    sereneseasons::seasons::Settings m_settings;
    int m_override = 0;  // 0 = auto, 1..4 = spring..winter
    bool m_hooked = false;
    std::uint64_t m_subscription = 0;
};
