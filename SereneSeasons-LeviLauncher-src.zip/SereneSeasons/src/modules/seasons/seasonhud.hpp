#pragma once

#include "../Module.hpp"
#include <mutex>

class SeasonHudModule : public Module {
public:
    SeasonHudModule();

    void onFrame() override;
    void onMenuRegistered() override;
    void loadConfig(const nlohmann::json& j) override;
    void saveConfig(nlohmann::json& j) override;

private:
    std::mutex m_configMutex;
    float hudPosX = 20.0f;
    float hudPosY = 20.0f;
    float m_size = 24.0f;
    bool m_showDay = true;
    bool m_showYear = false;
    bool m_background = true;
    float m_backgroundOpacity = 0.5f;
};
