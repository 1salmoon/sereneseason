#pragma once

#include <cstdint>

// Pure season math, modelled on Serene Seasons: 12 sub-seasons per year,
// 3 per season, each lasting `subSeasonDays` in-game days.
namespace sereneseasons::seasons {

enum class Season : int { Spring = 0, Summer = 1, Autumn = 2, Winter = 3 };

struct Settings {
    int dayDuration = 24000;     // ticks per in-game day
    int subSeasonDays = 8;       // days per sub-season (Serene Seasons default)
    int startSubSeason = 0;      // 0 = Early Spring ... 11 = Late Winter
    int seasonOverride = -1;     // -1 = automatic, 0..3 = lock to a season
};

struct State {
    Season season = Season::Spring;
    int subSeason = 0;           // 0..11
    int dayInSubSeason = 0;      // 0-based
    int subSeasonDays = 8;
    int dayInSeason = 0;         // 0-based
    int seasonDays = 24;
    int dayOfYear = 0;           // 0-based
    int yearDays = 96;
    int year = 1;
    float yearFraction = 0.0f;   // 0..1 through the year
};

State compute(std::int64_t worldTicks, const Settings& settings);

const char* seasonName(Season season);
const char* subSeasonName(int subSeason);

// Atmosphere multiplier for the current point in the year (smoothly blended).
struct Tint { float r, g, b; };
Tint atmosphereTint(float yearFraction);
Tint grassTint(float yearFraction);
Tint foliageTint(float yearFraction);

// Deterministic weather for a 6000 tick window. Same inputs -> same weather.
struct WeatherTarget { float rain; float lightning; };
WeatherTarget weatherForWindow(std::int64_t windowIndex, Season season);

}
