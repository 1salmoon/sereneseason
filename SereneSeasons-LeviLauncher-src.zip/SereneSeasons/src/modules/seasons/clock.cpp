#include "clock.hpp"

#include <algorithm>
#include <cmath>

namespace sereneseasons::seasons {

namespace {

constexpr const char* kSeasonNames[4] = {"Spring", "Summer", "Autumn", "Winter"};
constexpr const char* kSubNames[12] = {
    "Early Spring", "Mid Spring", "Late Spring",
    "Early Summer", "Mid Summer", "Late Summer",
    "Early Autumn", "Mid Autumn", "Late Autumn",
    "Early Winter", "Mid Winter", "Late Winter"};

std::uint64_t splitmix(std::uint64_t x) {
    x += 0x9E3779B97F4A7C15ull;
    x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9ull;
    x = (x ^ (x >> 27)) * 0x94D049BB133111EBull;
    return x ^ (x >> 31);
}

float unit(std::uint64_t h) {
    return static_cast<float>(h >> 40) / static_cast<float>(1ull << 24);
}

float smooth(float t) { return t * t * (3.0f - 2.0f * t); }

}

const char* seasonName(Season season) { return kSeasonNames[static_cast<int>(season) & 3]; }

const char* subSeasonName(int subSeason) {
    if (subSeason < 0) subSeason = 0;
    return kSubNames[subSeason % 12];
}

State compute(std::int64_t worldTicks, const Settings& in) {
    Settings s = in;
    s.dayDuration = std::max(s.dayDuration, 1);
    s.subSeasonDays = std::max(s.subSeasonDays, 1);
    s.startSubSeason = std::clamp(s.startSubSeason, 0, 11);
    if (worldTicks < 0) worldTicks = 0;

    const std::int64_t subTicks = static_cast<std::int64_t>(s.subSeasonDays) * s.dayDuration;
    const std::int64_t yearTicks = subTicks * 12;
    const std::int64_t total = worldTicks + subTicks * s.startSubSeason;
    const std::int64_t cycle = total % yearTicks;

    State st;
    st.subSeasonDays = s.subSeasonDays;
    st.seasonDays = s.subSeasonDays * 3;
    st.yearDays = s.subSeasonDays * 12;
    st.year = static_cast<int>(total / yearTicks) + 1;

    if (s.seasonOverride >= 0 && s.seasonOverride <= 3) {
        st.season = static_cast<Season>(s.seasonOverride);
        st.subSeason = s.seasonOverride * 3 + 1;
        st.dayInSubSeason = 0;
        st.dayInSeason = 0;
        st.dayOfYear = st.subSeason * s.subSeasonDays;
        st.yearFraction = s.seasonOverride * 0.25f + 0.125f;
        return st;
    }

    st.subSeason = static_cast<int>(cycle / subTicks);
    st.season = static_cast<Season>(st.subSeason / 3);
    st.dayInSubSeason = static_cast<int>((cycle % subTicks) / s.dayDuration);
    st.dayInSeason = (st.subSeason % 3) * s.subSeasonDays + st.dayInSubSeason;
    st.dayOfYear = static_cast<int>(cycle / s.dayDuration);
    st.yearFraction = static_cast<float>(cycle) / static_cast<float>(yearTicks);
    return st;
}

namespace {
Tint blend(const Tint (&anchors)[4], float f) {
    f = f - std::floor(f);
    const float pos = f * 4.0f - 0.5f;
    const float base = std::floor(pos);
    const float t = smooth(pos - base);
    const int a = ((static_cast<int>(base) % 4) + 4) % 4;
    const int b = (a + 1) % 4;
    return {anchors[a].r + (anchors[b].r - anchors[a].r) * t,
            anchors[a].g + (anchors[b].g - anchors[a].g) * t,
            anchors[a].b + (anchors[b].b - anchors[a].b) * t};
}
}

// Multipliers applied on top of the biome colour. Approximate; to be matched to the Java palette.
Tint grassTint(float f) {
    static const Tint anchors[4] = {
        {0.95f, 1.08f, 0.85f},  // spring: bright, fresh
        {1.00f, 1.00f, 0.95f},  // summer: lush
        {1.40f, 0.95f, 0.55f},  // autumn: dry, yellow-brown
        {1.15f, 0.95f, 0.95f},  // winter: pale, dormant
    };
    return blend(anchors, f);
}

Tint foliageTint(float f) {
    static const Tint anchors[4] = {
        {0.95f, 1.10f, 0.85f},  // spring
        {0.95f, 1.00f, 0.90f},  // summer
        {2.00f, 0.90f, 0.40f},  // autumn: orange / red
        {1.20f, 0.95f, 0.95f},  // winter: bare, grey-brown
    };
    return blend(anchors, f);
}

Tint atmosphereTint(float f) {
    // Anchors sit in the middle of each season.
    static const Tint anchors[4] = {
        {0.97f, 1.04f, 0.98f},  // spring: fresh green
        {1.04f, 1.02f, 0.93f},  // summer: warm
        {1.08f, 0.96f, 0.86f},  // autumn: amber
        {0.90f, 0.98f, 1.10f},  // winter: cold blue
    };
    f = f - std::floor(f);
    const float pos = f * 4.0f - 0.5f;             // 0 at spring centre
    const float base = std::floor(pos);
    const float t = smooth(pos - base);
    const int a = ((static_cast<int>(base) % 4) + 4) % 4;
    const int b = (a + 1) % 4;
    return {anchors[a].r + (anchors[b].r - anchors[a].r) * t,
            anchors[a].g + (anchors[b].g - anchors[a].g) * t,
            anchors[a].b + (anchors[b].b - anchors[a].b) * t};
}

WeatherTarget weatherForWindow(std::int64_t window, Season season) {
    struct Params { float rain; float thunder; };
    static const Params params[4] = {
        {0.40f, 0.15f},  // spring: frequent showers
        {0.12f, 0.35f},  // summer: mostly clear, rare but stormy
        {0.35f, 0.15f},  // autumn: damp
        {0.40f, 0.00f},  // winter: snow, no thunder
    };
    const Params& p = params[static_cast<int>(season) & 3];
    const std::uint64_t h = splitmix(static_cast<std::uint64_t>(window) * 2654435761ull + 0x5EA5);
    if (unit(h) >= p.rain) return {0.0f, 0.0f};
    const bool storm = unit(splitmix(h)) < p.thunder;
    return {1.0f, storm ? 1.0f : 0.0f};
}

}
