#pragma once
#include <cstdint>

// Finds a C++ vtable through its RTTI name in the loaded libminecraftpe.so and patches slots in place.
// No signatures needed, so it survives game updates as long as the class names stay.
namespace sereneseasons::vthook {

// Returns the address of slot 0, or nullptr.
std::uintptr_t* findVtable(const char* mangledTypeName);

// Replaces a slot. `original` receives the previous function pointer.
bool patchSlot(std::uintptr_t* vtable, int slot, void* detour, void** original);

}
