#include <sereneseasons/Api.hpp>
#include <sereneseasons/events/EventBus.hpp>
#include <sereneseasons/memory/Signatures.hpp>
#include "GameHooks.hpp"

namespace {
std::uintptr_t resolveSignature(std::uint16_t id) {
    if (id >= static_cast<std::uint16_t>(sereneseasons::memory::SignatureId::Count)) return 0;
    return sereneseasons::memory::resolve(static_cast<sereneseasons::memory::SignatureId>(id));
}

sereneseasons::sdk::ClientInstance* clientInstance() {
    return reinterpret_cast<sereneseasons::sdk::ClientInstance*>(sereneseasons::core::gamehooks::clientInstance());
}

std::uint64_t subscribe(sereneseasons::events::EventType type, sereneseasons::events::EventPriority priority, sereneseasons::api::EventCallback callback, void* userData) {
    if (!callback) return 0;
    return sereneseasons::events::bus().subscribeRaw(type, [type, callback, userData](void* payload) { callback(type, payload, userData); }, priority);
}

void unsubscribe(std::uint64_t subscription) {
    sereneseasons::events::bus().unsubscribe(subscription);
}

const sereneseasons::api::ApiV1 api{
    sereneseasons::api::AbiVersion,
    sizeof(sereneseasons::api::ApiV1),
    resolveSignature,
    clientInstance,
    subscribe,
    unsubscribe
};
}

extern "C" SERENESEASONS_API const sereneseasons::api::ApiV1* SereneSeasons_GetApi(std::uint32_t version) {
    return version == sereneseasons::api::AbiVersion ? &api : nullptr;
}
