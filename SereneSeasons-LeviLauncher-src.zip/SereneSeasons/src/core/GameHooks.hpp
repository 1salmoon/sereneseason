#pragma once

namespace sereneseasons::core::gamehooks {

bool install();
void uninstall();
void* clientInstance();

}
