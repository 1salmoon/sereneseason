#pragma once

namespace sereneseasons::core::uirender {

using Callback = void (*)(void*, void*);
bool subscribe(Callback callback);

}
