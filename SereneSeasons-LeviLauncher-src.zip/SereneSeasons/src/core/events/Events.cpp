#include <sereneseasons/events/EventBus.hpp>

namespace sereneseasons::events {

EventBus& bus() {
    static EventBus instance;
    return instance;
}

}
