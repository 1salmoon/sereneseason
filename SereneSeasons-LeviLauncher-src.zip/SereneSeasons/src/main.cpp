#include "core/Runtime.hpp"
#include <pl/Mod.hpp>

class SereneSeasonsMod {
public:
    static SereneSeasonsMod& instance() {
        static SereneSeasonsMod mod;
        return mod;
    }

    bool load(pl::mod::ModContext& context) { return sereneseasons::core::Runtime::get().load(context); }
    bool enable(pl::mod::ModContext& context) { return sereneseasons::core::Runtime::get().enable(context); }
    bool disable(pl::mod::ModContext& context) { return sereneseasons::core::Runtime::get().disable(context); }
    bool unload(pl::mod::ModContext& context) { return sereneseasons::core::Runtime::get().unload(context); }
};

PL_REGISTER_MOD(SereneSeasonsMod, SereneSeasonsMod::instance())
