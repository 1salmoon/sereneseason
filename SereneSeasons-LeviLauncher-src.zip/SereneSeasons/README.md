# SereneSeasons (LeviLauncher mod)

Mod native *standalone* untuk Minecraft Bedrock Android (LeviLauncher), terinspirasi Serene Seasons.
Kerangka (SDK, hook, menu) diturunkan dari BedrockTools (MIT, © RadiantByte). Tidak butuh BedrockTools terpasang.

## Fitur (sisi klien)
- **Kalender musim**: 12 sub-musim (Early/Mid/Late × Spring/Summer/Autumn/Winter), dihitung dari waktu dunia. Default 8 hari/sub-musim (96 hari/tahun), sama seperti Serene Seasons.
- **Cuaca musiman**: hujan sering di musim semi, jarang tapi berpetir di musim panas, lembap di musim gugur.
- **Salju di musim dingin**: presipitasi jadi salju di semua biome non-panas.
- **Tint atmosfer**: warna kabut/langit bergeser halus mengikuti musim.
- **Season HUD**: nama sub-musim dan hari (bisa dipindah di HUD editor).
- Menu: pilih musim tetap/otomatis, sub-musim awal, panjang sub-musim, toggle tiap efek.

## Batasan (penting)
- Murni **klien**: server tidak ikut berubah (tidak ada tanaman musiman, es/salju di blok, season sensor, kalender item).
- Warna rumput/daun **belum** berubah per musim (butuh hook biome color yang belum ada signature-nya).
- Musim mengikuti waktu dunia; jika server mematikan siklus siang, musim ikut diam.
- Cuaca musiman menimpa cuaca asli server secara lokal.
- Signature mengikuti versi Minecraft di `levimod.json` (`1.26.6X.X`); versi lain perlu update signature.

## Build
Butuh xmake + Android NDK r28c (lihat `.github/workflows/build.yml`):

    xmake f -y -p android -a arm64-v8a -m release --ndk=<path-ndk>
    xmake -y

Hasil: `build/android/arm64-v8a/release/SereneSeasons.levipack` → impor lewat mod manager LeviLauncher.

> Kode belum dikompilasi untuk Android di lingkungan pembuatnya (tanpa NDK/jaringan); logika musim sudah diuji di host.
